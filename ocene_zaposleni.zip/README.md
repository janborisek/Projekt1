<<<<<<< HEAD
=======
Baza ocene_zaposleni
![alt text](https://i.imgur.com/4lOVVQn.png)

Projekt ocene_zaposleni

Je aplikacija za šefe, ki lahko dodajajo zaposlene, jih ocenjujejo, plačujejo, nadzorujejo njihov napredek, kako dobro delajo...

Šefi lahko urejajo profile zaposlenih tako, da jim dodajajo/brisejo ocene, spremenijo profilno sliko, jih zbrišejo če jih odpusti

Je možnost prijave preko google računa
>>>>>>> d65a4e117578f01de99dcdd458351d9b732107f0
