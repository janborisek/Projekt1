<div id="copyright" class="container">
	<p>&copy; Velenje, 2018</p>
</div>
<!--nek basic footer -->