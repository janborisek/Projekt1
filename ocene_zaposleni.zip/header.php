<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900|Quicksand:400,700|Questrial" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<!--Glavni naslov je link na stran.php, spodaj pa odjava na odjava.php, header in vecino css-a iz random templata -->
                    <h1><a href="stran.php" class="linki">Ocenjevalec</a></h1>
                        <a href="odjava.php" class="linki">Odjavite se</a></div>
	</div>
</div>